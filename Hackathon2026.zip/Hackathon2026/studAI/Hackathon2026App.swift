import SwiftUI
import SwiftData

@main
struct Hackathon2026App: App {
    var body: some Scene {
        WindowGroup {
            SplashScreenView() // O VaultView() directamente si quieres empezar ahí
        }
        .modelContainer(for: Notebook.self)
    }
}
