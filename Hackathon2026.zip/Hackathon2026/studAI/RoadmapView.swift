import SwiftUI
import MapKit

struct RoadmapView: View {
    // 1. Estados de la vista
    @State private var selectedCareer = "Ingeniería en IA"
    let careers = ["Ingeniería en IA", "Ciberseguridad", "Ciencia de Datos"]
    
    // 2. Datos interactivos del Roadmap
    @State private var roadmaps: [String: [RoadmapStep]] = [
        "Ingeniería en IA": [
            RoadmapStep(title: "Bases Matemáticas", desc: "Domina el álgebra y cálculo.", details: "Antes de programar máquinas, necesitas entender cómo piensan. Enfócate en sacar excelentes notas en tus materias exactas.", duration: "Actual", icon: "function", done: false, tags: ["Matemáticas", "Lógica"], actionTitle: "Ver Khan Academy"),
            RoadmapStep(title: "Introducción a Python", desc: "Tu primer lenguaje.", details: "Aprende los fundamentos. Escribe pequeños scripts que te ayuden a resolver tareas automatizables de tus clases diarias.", duration: "3 Meses", icon: "terminal.fill", done: false, tags: ["Código", "Básico"], actionTitle: "Empezar Curso Gratis"),
            RoadmapStep(title: "Club de Robótica", desc: "Aplica la teoría.", details: "Únete o forma un equipo en tu escuela para construir y programar sensores básicos. Es vital para tu portafolio de admisión.", duration: "Próximo Semestre", icon: "cpu.fill", done: false, tags: ["Práctica", "Equipo"], actionTitle: "Ver Guía de Clubes")
        ],
        "Ciberseguridad": [
            RoadmapStep(title: "Higiene Digital", desc: "Protege tu propio entorno.", details: "Comienza configurando autenticación de dos factores en todo y aprende a gestionar contraseñas seguras. Sé tu primer cliente.", duration: "1 Semana", icon: "lock.shield.fill", done: false, tags: ["Prevención", "Básico"], actionTitle: "Guía de Seguridad"),
            RoadmapStep(title: "Exploración en Linux", desc: "El SO de los profesionales.", details: "Instala una distribución de Linux y aprende a moverte en la terminal de comandos. Es la herramienta principal.", duration: "2 Meses", icon: "display", done: false, tags: ["Sistemas", "Terminal"], actionTitle: "Descargar Ubuntu"),
            RoadmapStep(title: "Retos CTF", desc: "Juegos de hackeo ético.", details: "Participa en plataformas de 'Capture The Flag' para estudiantes. Aprenderás cómo piensan los atacantes en un entorno legal.", duration: "6 Meses", icon: "flag.checkered", done: false, tags: ["Reto", "Práctica"], actionTitle: "Ir a PicoCTF")
        ],
        "Ciencia de Datos": [
            RoadmapStep(title: "Estadística Aplicada", desc: "Dale sentido a los números.", details: "Asegúrate de entender bien probabilidad y estadística en tus clases actuales. Es la columna vertebral del análisis de datos.", duration: "Actual", icon: "chart.pie.fill", done: false, tags: ["Matemáticas", "Teoría"], actionTitle: "Repasar Fórmulas"),
            RoadmapStep(title: "De Excel a Código", desc: "Transición profesional.", details: "Empieza organizando datos en hojas de cálculo y luego intenta hacer lo mismo usando las librerías iniciales de Python.", duration: "3 Meses", icon: "tablecells.fill", done: false, tags: ["Herramientas", "Práctica"], actionTitle: "Descargar Datasets"),
            RoadmapStep(title: "Análisis de tu Pasión", desc: "Tu primer proyecto.", details: "Toma un tema que te apasione y crea gráficas para explicar esos datos a otros.", duration: "Próximo Semestre", icon: "chart.bar.xaxis", done: false, tags: ["Proyecto", "Portafolio"], actionTitle: "Ver Ejemplos")
        ]
    ]

    // 3. Cálculo de la barra de progreso
    var progressPercentage: Double {
        let steps = roadmaps[selectedCareer] ?? []
        guard !steps.isEmpty else { return 0 }
        let completed = steps.filter { $0.done }.count
        return Double(completed) / Double(steps.count)
    }
    
    // 4. Datos del Mapa de CDMX
    @State private var mapRegion = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 19.38, longitude: -99.16),
        span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
    )
    
    let universities = [
        University(name: "UNAM (Ciudad Universitaria)", coordinate: CLLocationCoordinate2D(latitude: 19.3299, longitude: -99.1862)),
        University(name: "IPN (Zacatenco)", coordinate: CLLocationCoordinate2D(latitude: 19.5045, longitude: -99.1469)),
        University(name: "Tec de Monterrey (CSF)", coordinate: CLLocationCoordinate2D(latitude: 19.3595, longitude: -99.2575))
    ]

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // --- SELECTOR DE CARRERA ---
                Picker("Carrera", selection: $selectedCareer) {
                    Text("IA (98%)").tag("Ingeniería en IA")
                    Text("Ciberseguridad (85%)").tag("Ciberseguridad")
                    Text("Datos (78%)").tag("Ciencia de Datos")
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                .padding(.top, 10)
                
                // --- BARRA DE PROGRESO ---
                VStack(spacing: 8) {
                    HStack {
                        Text("Avance de tu Ruta")
                            .font(.subheadline)
                            .bold()
                        Spacer()
                        Text("\(Int(progressPercentage * 100))%")
                            .font(.subheadline)
                            .bold()
                            .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                    }
                    ProgressView(value: progressPercentage)
                        .progressViewStyle(LinearProgressViewStyle(tint: progressPercentage == 1.0 ? .green : Color(red: 0.1, green: 0.2, blue: 0.4)))
                        .scaleEffect(x: 1, y: 1.5, anchor: .center)
                }
                .padding()
                .background(Color(.systemBackground))
                .cornerRadius(12)
                .padding()
                
                // --- CONTENIDO ESCROLABLE ---
                ScrollView {
                    let currentSteps = roadmaps[selectedCareer] ?? []
                    
                    // TARJETAS DE TAREAS
                    ForEach(Array(currentSteps.enumerated()), id: \.element.id) { index, step in
                        HStack(alignment: .top, spacing: 15) {
                            
                            // Columna Visual (Líneas y Círculos)
                            VStack(spacing: 0) {
                                ZStack {
                                    Circle()
                                        .fill(step.done ? Color.green : Color(red: 0.1, green: 0.2, blue: 0.4).opacity(0.1))
                                        .frame(width: 40, height: 40)
                                    Image(systemName: step.icon)
                                        .foregroundColor(step.done ? .white : Color(red: 0.1, green: 0.2, blue: 0.4))
                                        .font(.system(size: 18, weight: .bold))
                                }
                                if index != currentSteps.count - 1 {
                                    Rectangle()
                                        .fill(step.done ? Color.green : Color.gray.opacity(0.3))
                                        .frame(width: 3)
                                        .padding(.vertical, 4)
                                }
                            }
                            
                            // Tarjeta de Contenido
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    Text(step.title)
                                        .font(.headline)
                                        .strikethrough(step.done)
                                    Spacer()
                                    Button(action: { toggleStep(stepID: step.id) }) {
                                        Image(systemName: step.done ? "checkmark.circle.fill" : "circle")
                                            .font(.title)
                                            .foregroundColor(step.done ? .green : .gray.opacity(0.3))
                                    }
                                    .buttonStyle(PlainButtonStyle())
                                }
                                
                                Text(step.desc)
                                    .font(.subheadline)
                                    .bold()
                                    .foregroundColor(step.done ? .gray : Color(red: 0.1, green: 0.2, blue: 0.4))
                                
                                Text(step.details)
                                    .font(.footnote)
                                    .foregroundColor(.secondary)
                                    .lineLimit(4)
                                
                                // Botón de acción
                                if let actionTitle = step.actionTitle, !step.done {
                                    Button(action: {}) {
                                        HStack {
                                            Text(actionTitle)
                                            Image(systemName: "arrow.up.right.square")
                                        }
                                        .font(.caption)
                                        .bold()
                                        .foregroundColor(.white)
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 12)
                                        .background(Color(red: 0.1, green: 0.2, blue: 0.4))
                                        .cornerRadius(8)
                                    }
                                    .padding(.top, 4)
                                }
                                
                                Divider().padding(.vertical, 2)
                                
                                HStack {
                                    Label(step.duration, systemImage: "clock")
                                        .font(.caption2)
                                        .bold()
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    HStack(spacing: 6) {
                                        ForEach(step.tags, id: \.self) { tag in
                                            Text(tag)
                                                .font(.system(size: 10, weight: .bold))
                                                .padding(.horizontal, 8)
                                                .padding(.vertical, 4)
                                                .background(step.done ? Color.gray.opacity(0.1) : Color(red: 0.5, green: 1.0, blue: 0.85).opacity(0.3))
                                                .foregroundColor(step.done ? .gray : Color(red: 0.1, green: 0.2, blue: 0.4))
                                                .cornerRadius(6)
                                        }
                                    }
                                }
                            }
                            .padding()
                            .background(Color(.systemBackground))
                            .cornerRadius(16)
                            .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(step.done ? Color.green.opacity(0.5) : Color.gray.opacity(0.1), lineWidth: step.done ? 2 : 1))
                            .opacity(step.done ? 0.7 : 1.0)
                            .padding(.bottom, 25)
                        }
                        .padding(.horizontal)
                    }
                    
                    // --- MAPA DE UNIVERSIDADES (ESTILO PAPER) ---
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                                .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                                .font(.title2)
                            Text("Universidades Sugeridas en CDMX")
                                .font(.headline)
                                .bold()
                        }
                        .padding(.top, 15)
                        .padding(.horizontal, 15)
                        
                        Map(coordinateRegion: $mapRegion, annotationItems: universities) { school in
                            MapAnnotation(coordinate: school.coordinate) {
                                VStack {
                                    Image(systemName: "graduationcap.fill")
                                        .foregroundColor(.white)
                                        .padding(6)
                                        .background(Color(red: 0.1, green: 0.2, blue: 0.4))
                                        .clipShape(Circle())
                                        .shadow(radius: 3)
                                    
                                    Text(school.name)
                                        .font(.caption2)
                                        .bold()
                                        .padding(4)
                                        .background(Color(.systemBackground))
                                        .cornerRadius(4)
                                        .shadow(radius: 2)
                                }
                            }
                        }
                        .frame(height: 250)
                        .cornerRadius(12)
                        .padding(.horizontal, 15)
                        .padding(.bottom, 15)
                    }
                    .background(Color(.systemBackground))
                    .cornerRadius(16)
                    .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.gray.opacity(0.1), lineWidth: 1))
                    .padding(.horizontal)
                    .padding(.bottom, 30)
                    .padding(.top, 10)
                }
                .background(Color(red: 0.88, green: 0.92, blue: 0.92))
            }
            .navigationTitle("Roadmap Vocacional")
            .navigationBarTitleDisplayMode(.inline)
            .background(Color(red: 0.88, green: 0.92, blue: 0.92))
        }
    }
    
    func toggleStep(stepID: UUID) {
        if let index = roadmaps[selectedCareer]?.firstIndex(where: { $0.id == stepID }) {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.6)) {
                roadmaps[selectedCareer]?[index].done.toggle()
            }
        }
    }
}

struct RoadmapStep: Identifiable {
    let id = UUID()
    let title: String
    let desc: String
    let details: String
    let duration: String
    let icon: String
    var done: Bool
    let tags: [String]
    var actionTitle: String?
}

struct University: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
}
