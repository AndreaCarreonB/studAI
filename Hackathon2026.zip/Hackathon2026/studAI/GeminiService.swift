//
//  GeminiService.swift
//  Hackathon2026
//
//  Created by alumno on 20/04/26.
//

import Foundation
import GoogleGenerativeAI
import SwiftData

class GeminiService {
    // REEMPLAZA ESTO CON TU LLAVE REAL
    private let apiKey = "AIzaSyBNobDPpOK5lzw4uZj6n0hFtTzer0mhbLk"
    private let model: GenerativeModel

    init() {
        // En tu archivo GeminiService.swift, cambia la línea del init por esta:
        self.model = GenerativeModel(name: "gemini-pro", apiKey: apiKey)
    }

    func getCareerAdvice(userMessage: String, notebooks: [Notebook]) async -> String {
        // 1. Preparamos el contexto de tus datos reales
        let context = notebooks.map {
            "Materia: \($0.title), Calificación: \($0.grade), Contenido: \($0.contentText ?? "")"
        }.joined(separator: "\n")

        // 2. Creamos el "System Prompt" para que Gemini sepa su rol
        let prompt = """
        Eres un orientador vocacional experto en el sistema educativo de México. 
        Tienes acceso a los siguientes datos del estudiante Armando:
        \(context)
        
        El usuario dice: "\(userMessage)"
        
        Analiza sus notas y calificaciones. Si ves que destaca en ingeniería, sugiérele especialidades en tecnología. 
        Responde de forma humana, profesional y motivadora, como un mentor.
        """

        do {
            let response = try await model.generateContent(prompt)
            return response.text ?? "Lo siento, no pude procesar eso. Inténtalo de nuevo."
        } catch {
            return "Error de conexión con la IA: \(error.localizedDescription)"
        }
    }
}
