import SwiftUI
import PencilKit
import SwiftData

struct DetailView: View {
    @Bindable var notebook: Notebook
    @Query(sort: \Notebook.lastModified, order: .reverse) var allNotebooks: [Notebook]
    @Environment(\.modelContext) private var modelContext
    @Binding var path: NavigationPath
    
    @State private var canvasView = PKCanvasView()
    @State private var showPencil = false
    @State private var showAIAnalysis = false // Controla el panel de IA
    
    var body: some View {
        let contentBinding = Binding(
            get: { notebook.contentText ?? "" },
            set: { notebook.contentText = $0; notebook.lastModified = Date() }
        )
        
        VStack(spacing: 0) {
            // Panel de Indicador de Aptitud
            if !notebook.aiInsight.isEmpty {
                HStack {
                    Image(systemName: "sparkles")
                    Text(notebook.aiInsight)
                        .font(.caption)
                    Spacer()
                }
                .padding(8)
                .background(Color.blue.opacity(0.1))
                .foregroundColor(.blue)
            }

            TextField("Nombre de la materia", text: $notebook.title)
                .font(.title2).fontWeight(.bold).padding()
            
            Divider()
            
            if showPencil {
                CanvasView(canvasView: $canvasView)
                    .onAppear {
                        if let data = notebook.drawingData {
                            try? canvasView.drawing = PKDrawing(data: data)
                        }
                    }
                    .onDisappear { saveDrawing() }
            } else {
                TextEditor(text: contentBinding)
                    .padding()
                    .font(.system(size: 18))
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            // LADO IZQUIERDO: HOME
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                    path = NavigationPath()
                }) {
                    HStack { Image(systemName: "house.fill"); Text("Home") }
                }
            }
            
            // LADO DERECHO: NAVEGACIÓN Y ANÁLISIS
            ToolbarItemGroup(placement: .navigationBarTrailing) {
                // Botón de Análisis de IA (Aptitudes)
                Button(action: { analyzeAptitudes() }) {
                    Image(systemName: "brain.head.profile")
                        .foregroundColor(.purple)
                }

                Button(action: { navigate(direction: -1) }) { Image(systemName: "chevron.left") }
                Button(action: { navigate(direction: 1) }) { Image(systemName: "chevron.right") }

                Button(action: {
                    if showPencil { saveDrawing() }
                    showPencil.toggle()
                }) {
                    Image(systemName: showPencil ? "keyboard" : "pencil.and.outline")
                }
                
                Menu {
                    Button(action: shareNotebook) { Label("Compartir", systemImage: "square.and.arrow.up") }
                    Button(role: .destructive, action: deleteNotebook) { Label("Eliminar", systemImage: "trash") }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
            }
        }
    }
    
    // LÓGICA DE ANÁLISIS VOCACIONAL
    private func analyzeAptitudes() {
        let content = notebook.contentText?.lowercased() ?? ""
        
        // Simulación de análisis de palabras clave para sugerir especialidad
        if content.contains("algoritmo") || content.contains("código") || content.contains("lógica") {
            notebook.aiInsight = "Aptitud detectada: Desarrollo de Software / IA."
        } else if content.contains("diseño") || content.contains("color") || content.contains("arte") {
            notebook.aiInsight = "Aptitud detectada: Diseño Creativo / UX."
        } else if notebook.grade >= 9.0 {
            notebook.aiInsight = "Materia de alto rendimiento. Sugiere especialización técnica."
        } else {
            notebook.aiInsight = "Materia completada. Sigue registrando para mejorar el perfil."
        }
        
        notebook.lastModified = Date()
    }

    private func saveDrawing() {
        let data = canvasView.drawing.dataRepresentation()
        if !data.isEmpty { notebook.drawingData = data }
    }

    private func navigate(direction: Int) {
        saveDrawing()
        if let currentIndex = allNotebooks.firstIndex(where: { $0.id == notebook.id }) {
            let nextIndex = currentIndex + direction
            if allNotebooks.indices.contains(nextIndex) {
                path.removeLast()
                path.append(allNotebooks[nextIndex])
            }
        }
    }

    private func deleteNotebook() {
        modelContext.delete(notebook)
        path = NavigationPath()
    }

    private func shareNotebook() {
        let text = "Apuntes de \(notebook.title):\n\(notebook.contentText ?? "")"
        let av = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        if let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            scene.windows.first?.rootViewController?.present(av, animated: true)
        }
    }
}
