import SwiftUI
import SwiftData
import Charts // Necesario para la gráfica

// 1. Estructura de datos para la gráfica
struct AptitudeScore: Identifiable {
    let id = UUID()
    let area: String
    let score: Int
}

struct ProfileView: View {
    @Query var notebooks: [Notebook]
    
    // Aptitudes en formato etiqueta (Chips)
    let aiAptitudes = ["Pensamiento Lógico", "Resolución de Problems", "Análisis de Datos", "Algoritmos"]
    
    // 2. Datos de afinidad por grandes áreas (Cambiado según tu petición)
    let aptitudeScores = [
        AptitudeScore(area: "Ingeniería y TI", score: 95),
        AptitudeScore(area: "Negocios", score: 55),
        AptitudeScore(area: "Ciencias Sociales", score: 45),
        AptitudeScore(area: "Salud", score: 30),
        AptitudeScore(area: "Artes", score: 20)
    ]

    var body: some View {
        NavigationStack {
            // Fondo Verde Agua Claro para toda la lista
            List {
                // 1. CABECERA: INFORMACIÓN DEL ESTUDIANTE
                Section {
                    HStack(spacing: 16) {
                        Image(systemName: "person.circle.fill")
                            .font(.system(size: 70))
                            // Color Azul Petróleo para el icono
                            .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Armando Hernández")
                                .font(.title3)
                                .bold()
                            Text("Estudiante de Preparatoria") // Ajustado al nuevo enfoque
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            
                            
                        }
                    }
                    .padding(.vertical, 8)
                }
                // Color de fondo de la celda (Blanco para que resalte sobre el verde)
                .listRowBackground(Color.white)

                // 2. SECCIÓN DE RECOMENDACIONES CON NAVEGACIÓN
                Section(header: Text("Rutas de Carrera Recomendadas")) {
                    NavigationLink(destination: CareerDetailView(career: "Ingeniería en IA", icon: "cpu")) {
                        CareerRecommendationRow(
                            career: "Ingeniería en IA",
                            match: 98,
                            icon: "cpu",
                            description: "Basado en tus respuestas analíticas y de lógica."
                        )
                    }
                    
                    NavigationLink(destination: CareerDetailView(career: "Ciberseguridad", icon: "shield.fill")) {
                        CareerRecommendationRow(
                            career: "Ciberseguridad",
                            match: 85,
                            icon: "shield.fill",
                            description: "Detectamos un fuerte enfoque en seguridad y prevención."
                        )
                    }
                    
                    NavigationLink(destination: CareerDetailView(career: "Ciencia de Datos", icon: "chart.bar.xaxis")) {
                        CareerRecommendationRow(
                            career: "Ciencia de Datos",
                            match: 78,
                            icon: "chart.bar.xaxis",
                            description: "Tu manejo numérico es ideal para esta rama."
                        )
                    }
                }
                .listRowBackground(Color.white)

                // 3. APTITUDES DETECTADAS (FLOW LAYOUT)
                Section(header: Text("Etiquetas del Orientador")) {
                    FlowLayout(items: aiAptitudes)
                        .padding(.vertical, 4)
                }
                .listRowBackground(Color.white)
                
                // 4. NUEVA POSICIÓN: GRÁFICA DE ÁREAS (HASTA ABAJO)
                Section(header: Text("Afinidad por Áreas de Estudio")) {
                    VStack(alignment: .leading) {
                        Text("Porcentaje de compatibilidad")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .padding(.bottom, 5)
                        
                        Chart(aptitudeScores) { item in
                            BarMark(
                                x: .value("Compatibilidad", item.score),
                                y: .value("Área", item.area)
                            )
                            // Gradiente que combina Azul Petróleo y Verde Agua
                            .foregroundStyle(LinearGradient(colors: [Color(red: 0.1, green: 0.2, blue: 0.4), Color(red: 0.5, green: 1.0, blue: 0.85)], startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(4)
                            .annotation(position: .trailing) {
                                Text("\(item.score)%")
                                    .font(.caption2)
                                    .bold()
                                    .foregroundColor(.secondary)
                            }
                        }
                        .frame(height: 200)
                        // Configura el eje X de 0 a 100%
                        .chartXScale(domain: 0...100)
                    }
                    .padding(.vertical, 8)
                }
                .listRowBackground(Color.white)
            }
            .navigationTitle("Mi Perfil")
            // Fondo Verde Agua Claro para toda la List
            .background(Color(red: 0.88, green: 0.92, blue: 0.92))
            // Para asegurar que el fondo se aplique correctamente en Listas de estilo inal
            .scrollContentBackground(.hidden)
        }
    }
}

// MARK: - Componentes de Apoyo

struct CareerRecommendationRow: View {
    let career: String
    let match: Int
    let icon: String
    let description: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Image(systemName: icon)
                    // Color Azul Petróleo
                    .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                    .font(.headline)
                    .frame(width: 24)
                
                Text(career)
                    .font(.headline)
                
                Spacer()
                
                Text("\(match)%")
                    .font(.caption)
                    .bold()
                    .padding(.horizontal, 6)
                    .padding(.vertical, 2)
                    // Fondo condicional (Verde para match alto / Azul Petróleo suave para otros)
                    .background(match > 90 ? Color.green.opacity(0.2) : Color(red: 0.1, green: 0.2, blue: 0.4).opacity(0.2))
                    // Texto condicional (Verde / Azul Petróleo)
                    .foregroundColor(match > 90 ? .green : Color(red: 0.1, green: 0.2, blue: 0.4))
                    .cornerRadius(4)
            }
            
            Text(description)
                .font(.caption)
                .foregroundColor(.secondary)
                .lineLimit(2)
        }
        .padding(.vertical, 4)
    }
}

struct FlowLayout: View {
    let items: [String]
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(items, id: \.self) { item in
                    Text(item)
                        .font(.caption)
                        .bold()
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        // Fondo Verde Agua Claro
                        .background(Color(red: 0.88, green: 0.92, blue: 0.92))
                        // Texto Azul Petróleo
                        .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                        .cornerRadius(10)
                }
            }
        }
    }
}
