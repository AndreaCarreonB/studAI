import SwiftUI

// MARK: - VISTA PRINCIPAL (Splash Screen)
struct SplashScreenView: View {
    @State private var isActive = false
    @State private var size = 0.8
    @State private var opacity = 0.5
    
    // 1. Cambiamos AppStorage por un State normal. Siempre inicia en true.
    @State private var showOnboarding: Bool = true
    
    var body: some View {
        if isActive {
            ZStack {
                // 2. Invertimos la lógica: Si showOnboarding es true, muestra la intro.
                if showOnboarding {
                    // Pasamos la variable conectada (Binding) a la siguiente vista
                    OnboardingView(showOnboarding: $showOnboarding)
                        .transition(.opacity)
                } else {
                    ContentView()
                        .transition(.opacity)
                }
            }
            .animation(.easeInOut(duration: 0.6), value: showOnboarding)
            
        } else {
            ZStack {
                Color(red: 0.88, green: 0.92, blue: 0.92)
                    .ignoresSafeArea()
                
                VStack {
                    VStack(spacing: 15) {
                        Image("logo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 250, height: 250)
                            .padding(.bottom, 20)
                        
                        Text("studAI")
                            .font(.system(size: 40, weight: .bold, design: .rounded))
                            .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                    }
                    .scaleEffect(size)
                    .opacity(opacity)
                    .onAppear {
                        withAnimation(.easeIn(duration: 1.2)) {
                            self.size = 1.0
                            self.opacity = 1.0
                        }
                    }
                }
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                    withAnimation {
                        self.isActive = true
                    }
                }
            }
        }
    }
}

// MARK: - VISTA DE ONBOARDING
struct OnboardingView: View {
    // 3. Recibimos la variable desde la pantalla de Splash
    @Binding var showOnboarding: Bool
    @State private var currentStep = 0
    
    let steps: [OnboardingStep] = [
        OnboardingStep(
            image: "sparkles",
            title: "Descubre tu Vocación",
            description: "Platica con nuestra IA para descubrir las carreras que mejor se adaptan a tu perfil y pasiones."
        ),
        OnboardingStep(
            image: "map.fill",
            title: "Rutas Personalizadas",
            description: "Obtén un Roadmap paso a paso con las habilidades y herramientas que necesitas aprender desde hoy."
        ),
        OnboardingStep(
            image: "graduationcap.fill",
            title: "Encuentra tu Universidad",
            description: "Explora las mejores opciones educativas en tu ciudad para dar el siguiente gran salto."
        )
    ]
    
    var body: some View {
        ZStack {
            Color(red: 0.88, green: 0.92, blue: 0.92).ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentStep) {
                    ForEach(0..<steps.count, id: \.self) { index in
                        VStack(spacing: 20) {
                            Spacer()
                            
                            Image(systemName: steps[index].image)
                                .resizable()
                                .scaledToFit()
                                .frame(width: 120, height: 120)
                                .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                                .padding(.bottom, 30)
                            
                            Text(steps[index].title)
                                .font(.title)
                                .bold()
                                .multilineTextAlignment(.center)
                                .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                            
                            Text(steps[index].description)
                                .font(.body)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 32)
                                .foregroundColor(.secondary)
                            
                            Spacer()
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                
                Button(action: {
                    if currentStep < steps.count - 1 {
                        withAnimation {
                            currentStep += 1
                        }
                    } else {
                        // 4. Cambiamos la variable a false para que la app avance al ContentView
                        withAnimation {
                            showOnboarding = false
                        }
                    }
                }) {
                    Text(currentStep < steps.count - 1 ? "Siguiente" : "¡Empezar a explorar!")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(red: 0.1, green: 0.2, blue: 0.4))
                        .cornerRadius(16)
                        .padding(.horizontal, 32)
                }
                .padding(.bottom, 40)
            }
        }
    }
}

// MARK: - ESTRUCTURA DE DATOS PARA EL ONBOARDING
struct OnboardingStep {
    let image: String
    let title: String
    let description: String
}
