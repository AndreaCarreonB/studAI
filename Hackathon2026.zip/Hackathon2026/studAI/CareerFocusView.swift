import SwiftUI

struct CareerFocusView: View {
    // 1. EL SALUDO INICIAL (Pregunta General de Áreas)
    @State private var messages: [Message] = [
        Message(text: "¡Hola! Estás en una etapa increíble para diseñar tu futuro. Soy studAI. Para empezar desde lo más general: en tu día a día, ¿qué te llama más la atención? ¿Entender cómo funciona la naturaleza y la salud, analizar el comportamiento de la sociedad, expresarte a través del arte, o resolver problemas lógicos y entender cómo se construyen las cosas?", isUser: false)
    ]
    
    @State private var newMessage: String = ""
    @State private var isTyping = false
    
    // 2. EL GUION DE LA IA (El Embudo)
    @State private var stepIndex = 0
    let aiScript = [
        // Respuesta al Turno 1 (Filtrando Ingeniería)
        "¡Genial! Tu perfil encaja perfectamente en el área de **Ingenierías y Ciencias Exactas**. Dentro de este mundo hay muchas ramas. ¿Te atrae más la idea de construir cosas físicas (como robótica o electrónica), o prefieres el mundo digital, creando software, algoritmos y manejando información?",
        
        // Respuesta al Turno 2 (Filtrando la especialidad y pidiendo ciudad)
        "¡El mundo del software tiene un crecimiento imparable! Pensando en eso, ¿te ves más enseñándole a las máquinas a tomar decisiones de forma automática, o prefieres ser el experto que protege toda esa información de los hackers? Y por cierto, para buscarte excelentes opciones universitarias, ¿en qué ciudad te encuentras?",
        
        // Respuesta al Turno 3 (El Gran Final)
        "¡Tengo la radiografía exacta de tu vocación! Tienes una mente analítica ideal para el futuro tecnológico. La Ciudad de México tiene opciones de élite para ti.\n\nTu match principal es **Ingeniería en Inteligencia Artificial (98%)**, seguido por Ciberseguridad (85%) y Ciencia de Datos (78%).\n\nHe actualizado tu 'Perfil' y he añadido un mapa universitario a tu 'Roadmap'. ¡Ve a revisarlos en el menú inferior!"
    ]
        
    @State private var chatCompleted = false

    var body: some View {
        NavigationStack {
            ZStack {
                // Fondo ligeramente gris azulado verdoso para que resalten las burbujas
                Color(red: 0.88, green: 0.92, blue: 0.92).ignoresSafeArea()
                
                VStack(spacing: 0) {
                    // ÁREA DEL CHAT
                    ScrollViewReader { proxy in
                        ScrollView {
                            VStack(spacing: 16) {
                                Spacer().frame(height: 10)
                                
                                ForEach(messages) { msg in
                                    ChatBubble(message: msg)
                                }
                                
                                if isTyping {
                                    TypingIndicator()
                                        .id("typing")
                                }
                                
                                Spacer().frame(height: 10)
                            }
                            .padding(.horizontal)
                        }
                        .onChange(of: messages.count) { _ in
                            withAnimation { proxy.scrollTo(messages.last?.id, anchor: .bottom) }
                        }
                        .onChange(of: isTyping) { _ in
                            if isTyping {
                                withAnimation { proxy.scrollTo("typing", anchor: .bottom) }
                            }
                        }
                    }
                    
                    // ÁREA DE INPUT
                    VStack {
                        Divider()
                        if !chatCompleted {
                            HStack(alignment: .bottom) {
                                TextField("Escribe aquí...", text: $newMessage, axis: .vertical)
                                    .padding(12)
                                    .lineLimit(1...4) // Permite que el cuadro crezca si escribes mucho
                                    .background(Color(.systemBackground))
                                    .cornerRadius(20)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                                    )
                                
                                Button(action: simulateChat) {
                                    Image(systemName: "arrow.up")
                                        .font(.system(size: 18, weight: .bold))
                                        .foregroundColor(.white)
                                        .padding(10)
                                        .background(newMessage.isEmpty ? Color.gray.opacity(0.5) : Color(red: 0.1, green: 0.2, blue: 0.4))
                                        .clipShape(Circle())
                                }
                                .disabled(newMessage.isEmpty)
                            }
                            .padding(.horizontal)
                            .padding(.vertical, 10)
                            .background(Color(red: 0.88, green: 0.92, blue: 0.92))
                        } else {
                            // Mensaje final
                            VStack(spacing: 5) {
                                Text("Ruta Vocacional Generada")
                                    .font(.headline)
                                    .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                                Text("Revisa 'Mi Ruta' y 'Perfil' para continuar.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white.opacity(0.8))
                            .cornerRadius(15)
                            .padding()
                        }
                    }
                }
            }
            .navigationTitle("studAI")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    func simulateChat() {
        let userText = newMessage
        guard !userText.isEmpty else { return }
        
        messages.append(Message(text: userText, isUser: true))
        newMessage = ""
        isTyping = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.8) {
            isTyping = false
            
            if stepIndex < aiScript.count {
                messages.append(Message(text: aiScript[stepIndex], isUser: false))
                stepIndex += 1
                
                if stepIndex == aiScript.count {
                    chatCompleted = true
                }
            }
        }
    }
}

// MARK: - Componentes Visuales del Chat

struct Message: Identifiable {
    let id = UUID()
    let text: String
    let isUser: Bool
}

struct ChatBubble: View {
    let message: Message
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if !message.isUser {
                
                ZStack {
                    Circle()
                        .fill(LinearGradient(colors: [Color(red: 0.1, green: 0.4, blue: 0.6), Color(red: 0.5, green: 1.0, blue: 0.85)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 32, height: 32)
                    Image(systemName: "sparkles")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.white)
                }
            } else {
                Spacer()
            }
            
            Text(message.text)
                .padding(.horizontal, 16)
                .padding(.vertical, 12)
                .background(message.isUser ? Color(red: 0.1, green: 0.2, blue: 0.4) : Color(.systemBackground))
                .foregroundColor(message.isUser ? .white : .primary)
                .clipShape(RoundedCornerShape(radius: 18, corners: message.isUser ? [.topLeft, .topRight, .bottomLeft] : [.topLeft, .topRight, .bottomRight]))
                .shadow(color: Color.black.opacity(0.04), radius: 4, x: 0, y: 2)
            
            if !message.isUser {
                Spacer()
            }
        }
    }
}

// Animación de "Escribiendo..."
struct TypingIndicator: View {
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            ZStack {
                Circle()
                    .fill(LinearGradient(colors: [Color(red: 0.1, green: 0.4, blue: 0.6), Color(red: 0.5, green: 1.0, blue: 0.85)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 32, height: 32)
                Image(systemName: "sparkles")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.white)
            }
            
            HStack(spacing: 4) {
                Circle().frame(width: 6, height: 6).opacity(0.4)
                Circle().frame(width: 6, height: 6).opacity(0.6)
                Circle().frame(width: 6, height: 6).opacity(0.8)
            }
            .foregroundColor(Color(red: 0.1, green: 0.4, blue: 0.6))
            .padding(.horizontal, 16)
            .padding(.vertical, 16)
            .background(Color(.systemBackground))
            .clipShape(RoundedCornerShape(radius: 18, corners: [.topLeft, .topRight, .bottomRight]))
            .shadow(color: Color.black.opacity(0.04), radius: 4, x: 0, y: 2)
            
            Spacer()
        }
    }
}

// Herramienta para redondear solo ciertas esquinas
struct RoundedCornerShape: Shape {
    var radius: CGFloat
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
