import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            // Pestaña de IA y Chatbot
            CareerFocusView()
                .tabItem {
                    Label("IA & Enfoque", systemImage: "brain.head.profile")
                }
            
            // Biblioteca
            //VaultView()
            //    .tabItem {
            //        Label("Biblioteca", systemImage: "books.vertical.fill")
            //    }
            
            // Perfil y Aptitudes
            ProfileView()
                .tabItem {
                    Label("Perfil", systemImage: "person.text.rectangle")
                }
            
            // Perfil y Aptitudes
            RoadmapView()
                .tabItem {
                    Label("Roadmap", systemImage: "map.fill")
                }
        }
        .accentColor(.blue)
    }
}
