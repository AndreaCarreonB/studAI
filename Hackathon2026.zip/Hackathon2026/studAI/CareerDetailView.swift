import SwiftUI

struct CareerDetailView: View {
    let career: String
    let icon: String
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Cabecera Visual
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        // Gradiente que combina Azul Petróleo y Verde Agua (premium)
                        .fill(LinearGradient(colors: [Color(red: 0.1, green: 0.2, blue: 0.4), Color(red: 0.5, green: 1.0, blue: 0.85)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(height: 150)
                    
                    VStack {
                        Image(systemName: icon)
                            .font(.system(size: 50))
                            .foregroundColor(.white)
                        Text(career)
                            .font(.title2)
                            .bold()
                            .foregroundColor(.white)
                    }
                }
                .padding(.horizontal)

                VStack(alignment: .leading, spacing: 15) {
                    // --- EL DÍA A DÍA ---
                    Label("El Día a Día", systemImage: "clock.badge.checkmark")
                        .font(.headline)
                        // Color Azul Petróleo
                        .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                    
                    Text(dailyRoutine(for: career))
                        .font(.body)
                        .foregroundColor(.secondary)
                    
                    Divider()

                    // --- SUELDO APROXIMADO ---
                    Label("Sueldo Mensual (MXN)", systemImage: "banknote")
                        .font(.headline)
                        // Color Azul Petróleo
                        .foregroundColor(Color(red: 0.1, green: 0.2, blue: 0.4))
                    
                    HStack {
                        VStack(alignment: .leading) {
                            Text("Junior")
                                .font(.caption)
                            Text(salary(for: career, level: "JR"))
                                .font(.title3)
                                .bold()
                        }
                        Spacer()
                        VStack(alignment: .trailing) {
                            Text("Senior")
                                .font(.caption)
                            Text(salary(for: career, level: "SR"))
                                .font(.title3)
                                .bold()
                                // Verde para resaltar el sueldo senior
                                .foregroundColor(.green)
                        }
                    }
                    .padding()
                    // Fondo Azul Petróleo suave para el cuadro de sueldo
                    .background(Color(red: 0.1, green: 0.2, blue: 0.4).opacity(0.1))
                    .cornerRadius(12)
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .navigationTitle("Detalle de Carrera")
        .navigationBarTitleDisplayMode(.inline)
        // Fondo Verde Agua Claro para toda la vista
        .background(Color(red: 0.88, green: 0.92, blue: 0.92))
    }

    // Lógica de datos (Simulando lo que Gemini daría)
    func dailyRoutine(for career: String) -> String {
        switch career {
        case "Ingeniería en IA":
            return "Tu mañana empieza analizando datasets y entrenando modelos en la nube. Pasas tiempo optimizando algoritmos y colaborando con ingenieros de datos para implementar soluciones que automatizan decisiones."
        case "Ciberseguridad":
            return "Monitorizas redes en busca de intrusiones, realizas pruebas de penetración (pentesting) y diseñas arquitecturas seguras. Es un puesto de alta responsabilidad donde la prevención es clave."
        default:
            return "Investigación de mercado, análisis de tendencias y aplicación de tus conocimientos técnicos para resolver problemas complejos de la industria."
        }
    }

    func salary(for career: String, level: String) -> String {
        let salaries: [String: [String: String]] = [
            "Ingeniería en IA": ["JR": "$25,000", "SR": "$85,000+"],
            "Ciberseguridad": ["JR": "$22,000", "SR": "$75,000+"],
            "Ciencia de Datos": ["JR": "$20,000", "SR": "$70,000+"]
        ]
        return salaries[career]?[level] ?? "$15,000"
    }
}
