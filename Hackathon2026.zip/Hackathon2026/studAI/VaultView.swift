import SwiftUI
import SwiftData

struct VaultView: View {
    @Query(sort: \Notebook.lastModified, order: .reverse) var allNotebooks: [Notebook]
    @Environment(\.modelContext) private var modelContext
    
    // Control de navegación profunda
    @State private var navPath = NavigationPath()
    
    @State private var isPrepaExpanded = true
    @State private var isUniExpanded = false
    
    let columns = [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        NavigationStack(path: $navPath) {
            List {
                DisclosureGroup(isExpanded: $isPrepaExpanded) {
                    LevelContent(level: "Prepa", notebooks: allNotebooks, columns: columns)
                } label: {
                    Label("Preparatoria", systemImage: "graduationcap.fill").foregroundColor(.blue)
                }

                DisclosureGroup(isExpanded: $isUniExpanded) {
                    LevelContent(level: "Universidad", notebooks: allNotebooks, columns: columns)
                } label: {
                    Label("Universidad", systemImage: "building.columns.fill").foregroundColor(.orange)
                }
            }
            .listStyle(InsetGroupedListStyle())
            .navigationTitle("Mi Biblioteca")
            // Definimos a dónde ir cuando se selecciona un Notebook
            .navigationDestination(for: Notebook.self) { notebook in
                DetailView(notebook: notebook, path: $navPath)
            }
            .toolbar {
                Button(action: addNotebook) {
                    Image(systemName: "plus.app.fill").font(.title2)
                }
            }
        }
    }
    
    func addNotebook() {
        let level = isPrepaExpanded ? "Prepa" : "Universidad"
        let new = Notebook(title: "Nueva Materia", educationLevel: level, schoolYear: 2026)
        modelContext.insert(new)
    }
}

struct LevelContent: View {
    let level: String
    let notebooks: [Notebook]
    let columns: [GridItem]
    
    var notebooksByYear: [Int: [Notebook]] {
        let filtered = notebooks.filter { $0.educationLevel == level }
        return Dictionary(grouping: filtered, by: { $0.schoolYear })
    }
    
    var body: some View {
        ForEach(notebooksByYear.keys.sorted(by: >), id: \.self) { year in
            DisclosureGroup("Año \(String(year))") {
                LazyVGrid(columns: columns, spacing: 15) {
                    ForEach(notebooksByYear[year] ?? []) { notebook in
                        // Usamos 'value' para activar la navegación programática
                        NavigationLink(value: notebook) {
                            VStack {
                                Image(systemName: notebook.icon)
                                    .foregroundColor(.white)
                                    .frame(width: 40, height: 40)
                                    .background(level == "Prepa" ? Color.blue.gradient : Color.orange.gradient)
                                    .cornerRadius(10)
                                Text(notebook.title).font(.system(size: 10)).foregroundColor(.primary).lineLimit(1)
                            }
                            .padding(8).background(Color(.tertiarySystemBackground)).cornerRadius(12)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }
                .padding(.vertical, 10)
            }
        }
    }
}
