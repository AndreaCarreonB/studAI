import Foundation
import SwiftData

@Model
class Notebook {
    var title: String
    var contentText: String?
    var drawingData: Data?
    var icon: String
    var grade: Double
    var aiInsight: String
    var educationLevel: String
    var schoolYear: Int
    var lastModified: Date
    
    init(title: String,
         contentText: String? = "",
         drawingData: Data? = nil,
         icon: String = "book",
         grade: Double = 0.0,
         aiInsight: String = "Analizando...",
         educationLevel: String = "Prepa",
         schoolYear: Int = 2026) {
        self.title = title
        self.contentText = contentText
        self.drawingData = drawingData
        self.icon = icon
        self.grade = grade
        self.aiInsight = aiInsight
        self.educationLevel = educationLevel
        self.schoolYear = schoolYear
        self.lastModified = Date()
    }
}
